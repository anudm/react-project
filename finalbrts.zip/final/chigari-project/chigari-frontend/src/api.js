// src/api.js
import axios from "axios";

const API = "http://localhost:5000/api";

export const registerUser = (data) =>
  axios.post(`${API}/register`, data).then(res => res.data);

export const loginUser = (data) =>
  axios.post(`${API}/login`, data).then(res => res.data);

export const searchTrips = (params) =>
  axios.get(`${API}/trips`, { params }).then(res => res.data);

export const getBookedSeats = (tripId) =>
  axios.get(`${API}/bookings/${tripId}`).then(res => res.data);

export const createBooking = (data) =>
  axios.post(`${API}/bookings`, data).then(res => res.data);

export const getUserBookings = (userId) =>
  axios.get(`${API}/bookings/user/${userId}`).then(res => res.data);

export const cancelBooking = (id) =>
  axios.put(`${API}/bookings/cancel/${id}`).then(res => res.data);

export const checkPNR = (pnr) =>
  axios.get(`${API}/bookings/pnr/${pnr}`).then(res => res.data);

// User Profile API
export const updateProfile = (data) =>
  axios.put(`${API}/user/profile`, data).then(res => res.data);

export const changePassword = (data) =>
  axios.put(`${API}/user/password`, data).then(res => res.data);

export const deleteUser = (id) =>
  axios.delete(`${API}/user/${id}`).then(res => res.data);

// Admin API - Buses
export const getBuses = () =>
  axios.get(`${API}/admin/buses`).then(res => res.data);

export const addBus = (data) =>
  axios.post(`${API}/admin/buses`, data).then(res => res.data);

export const deleteBus = (id) =>
  axios.delete(`${API}/admin/buses/${id}`).then(res => res.data);

// Admin API - Routes
export const getAdminRoutes = () =>
  axios.get(`${API}/admin/routes`).then(res => res.data);

export const addRoute = (data) =>
  axios.post(`${API}/admin/routes`, data).then(res => res.data);

export const deleteRoute = (id) =>
  axios.delete(`${API}/admin/routes/${id}`).then(res => res.data);

// Admin API - Trips
export const getAdminTrips = () =>
  axios.get(`${API}/admin/trips`).then(res => res.data);

export const addTrip = (data) =>
  axios.post(`${API}/admin/trips`, data).then(res => res.data);

export const deleteTrip = (id) =>
  axios.delete(`${API}/admin/trips/${id}`).then(res => res.data);
