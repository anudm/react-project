import React, { useState } from "react";

const AutocompleteInput = ({ label, value, onChange, options }) => {
  const [show, setShow] = useState(false);

  const filtered = options.filter((item) =>
    item.toLowerCase().includes(value.toLowerCase())
  );

  return (
    <div className="auto">
      <label>{label}</label>

      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onFocus={() => setShow(true)}
        onBlur={() => setTimeout(() => setShow(false), 200)}
      />

      {show && value && (
        <div className="dropdown">
          {filtered.map((item) => (
            <div
              className="item"
              key={item}
              onMouseDown={() => onChange(item)}
            >
              {item}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AutocompleteInput;
