import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { updateProfile, changePassword, deleteUser } from "../api";

const UserProfile = ({ user, onChangeUser, onClose }) => {
  const [activeTab, setActiveTab] = useState("profile");
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const [formData, setFormData] = useState({
    full_name: user?.full_name || "",
    email: user?.email || "",
    phone: user?.phone || "",
    gender: user?.gender || "Not Specified",
    date_of_birth: user?.date_of_birth ? user.date_of_birth.split('T')[0] : "",
    city: user?.city || "",
    state: user?.state || "",
  });

  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    smsNotifications: true,
    bookingUpdates: true,
    promoOffers: true,
  });

  const [savedSuccessfully, setSavedSuccessfully] = useState(false);
  const navigate = useNavigate();

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handlePasswordChange = (e) => {
    const { name, value } = e.target;
    setPasswordData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleNotificationChange = (setting) => {
    setNotificationSettings((prev) => ({
      ...prev,
      [setting]: !prev[setting],
    }));
  };

  const validateProfile = () => {
    if (!formData.full_name.trim()) return "Full Name is required";
    if (!formData.email.trim()) return "Email is required";
    if (!/\S+@\S+\.\S+/.test(formData.email)) return "Invalid email address";

    // Strict Phone Validation
    if (!formData.phone || !formData.phone.trim()) return "Phone number is required";
    if (!/^\d{10}$/.test(formData.phone)) return "Phone number must be exactly 10 digits";

    // Strict Gender Validation
    if (!formData.gender || formData.gender === "Not Specified") return "Please select a Gender";

    // Strict Date of Birth Validation
    if (!formData.date_of_birth) return "Date of Birth is required";
    const selectedDate = new Date(formData.date_of_birth);
    const today = new Date();
    if (selectedDate > today) return "Date of Birth cannot be in the future";

    // Strict City & State Validation
    if (!formData.city || formData.city.trim().length < 2) return "City is required";
    if (!formData.state || formData.state.trim().length < 2) return "State is required";

    return null;
  };

  const handleSaveProfile = async () => {
    setError(null);
    const valError = validateProfile();
    if (valError) {
      alert(valError);
      return;
    }

    setIsLoading(true);
    try {
      const res = await updateProfile({ ...formData, id: user.id });
      if (res.success) {
        onChangeUser(res.user);
        setSavedSuccessfully(true);
        setIsEditing(false);
        setTimeout(() => setSavedSuccessfully(false), 3000);
      } else {
        alert(res.message);
      }
    } catch (e) {
      alert("Failed to update profile. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleChangePassword = async () => {
    setError(null);
    if (!passwordData.currentPassword) {
      alert("Please enter current password");
      return;
    }
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      alert("New passwords do not match!");
      return;
    }
    if (passwordData.newPassword.length < 6) {
      alert("Password must be at least 6 characters!");
      return;
    }

    setIsLoading(true);
    try {
      const res = await changePassword({
        id: user.id,
        currentPassword: passwordData.currentPassword,
        newPassword: passwordData.newPassword
      });

      if (res.success) {
        alert("Password changed successfully!");
        setPasswordData({
          currentPassword: "",
          newPassword: "",
          confirmPassword: "",
        });
      } else {
        alert(res.message);
      }
    } catch (e) {
      alert("Failed to change password.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteAccount = async () => {
    const confirm = window.confirm(
      "Are you sure you want to delete your account? This will cancel all your bookings and cannot be undone."
    );
    if (!confirm) return;

    setIsLoading(true);
    try {
      const res = await deleteUser(user.id);
      if (res.success) {
        alert("Account deleted successfully.");
        localStorage.clear();
        window.location.href = "/"; // Force full reload to reset state
      } else {
        alert("Failed to delete account: " + res.message);
      }
    } catch (e) {
      alert("Error deleting account.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.clear();
    onClose();
    navigate("/login");
  };

  return (
    <div className="profile-modal-overlay" onClick={onClose}>
      <div className="profile-modal" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div className="profile-header">
          <h2>My Profile & Settings</h2>
          <button className="close-btn" onClick={onClose}>×</button>
        </div>

        {/* Tab Navigation */}
        <div className="profile-tabs">
          <button
            className={`profile-tab ${activeTab === "profile" ? "active" : ""}`}
            onClick={() => setActiveTab("profile")}
          >
            👤 Profile
          </button>
          <button
            className={`profile-tab ${activeTab === "security" ? "active" : ""}`}
            onClick={() => setActiveTab("security")}
          >
            🔐 Security
          </button>
          <button
            className={`profile-tab ${activeTab === "preferences" ? "active" : ""}`}
            onClick={() => setActiveTab("preferences")}
          >
            ⚙️ Preferences
          </button>
          <button
            className={`profile-tab ${activeTab === "account" ? "active" : ""}`}
            onClick={() => setActiveTab("account")}
          >
            ⚡ Account
          </button>
        </div>

        {/* Tab Content */}
        <div className="profile-content">
          {/* PROFILE TAB */}
          {activeTab === "profile" && (
            <div className="tab-section">
              {savedSuccessfully && (
                <div className="success-message">✓ Profile updated successfully!</div>
              )}

              <div className="profile-info-section">
                <div className="profile-avatar">
                  <img
                    src={`https://ui-avatars.com/api/?name=${user?.full_name || "User"}&background=00eaff&color=000&size=120`}
                    alt="Profile"
                  />
                </div>

                {!isEditing ? (
                  <div className="profile-view">
                    <div className="info-row">
                      <span className="info-label">Full Name</span>
                      <span className="info-value">{formData.full_name}</span>
                    </div>
                    <div className="info-row">
                      <span className="info-label">Email</span>
                      <span className="info-value">{formData.email}</span>
                    </div>
                    <div className="info-row">
                      <span className="info-label">Phone</span>
                      <span className="info-value">{formData.phone || "Not provided"}</span>
                    </div>
                    <div className="info-row">
                      <span className="info-label">Gender</span>
                      <span className="info-value">{formData.gender}</span>
                    </div>
                    <div className="info-row">
                      <span className="info-label">Date of Birth</span>
                      <span className="info-value">{formData.date_of_birth || "Not provided"}</span>
                    </div>
                    <div className="info-row">
                      <span className="info-label">City</span>
                      <span className="info-value">{formData.city || "Not provided"}</span>
                    </div>
                    <div className="info-row">
                      <span className="info-label">State</span>
                      <span className="info-value">{formData.state || "Not provided"}</span>
                    </div>
                    <button className="btn-edit" onClick={() => setIsEditing(true)}>
                      ✏️ Edit Profile
                    </button>
                  </div>
                ) : (
                  <div className="profile-edit">
                    <div className="form-group">
                      <label>Full Name *</label>
                      <input
                        type="text"
                        name="full_name"
                        value={formData.full_name}
                        onChange={handleInputChange}
                        placeholder="Enter your full name"
                      />
                    </div>
                    <div className="form-group">
                      <label>Email *</label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="Enter your email"
                      />
                    </div>
                    <div className="form-group">
                      <label>Phone *</label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        placeholder="10 digit mobile number"
                        maxLength="10"
                      />
                    </div>
                    <div className="form-group">
                      <label>Gender *</label>
                      <select name="gender" value={formData.gender} onChange={handleInputChange}>
                        <option>Not Specified</option>
                        <option>Male</option>
                        <option>Female</option>
                        <option>Other</option>
                      </select>
                    </div>
                    <div className="form-group">
                      <label>Date of Birth *</label>
                      <input
                        type="date"
                        name="date_of_birth"
                        value={formData.date_of_birth}
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="form-group">
                      <label>City *</label>
                      <input
                        type="text"
                        name="city"
                        value={formData.city}
                        onChange={handleInputChange}
                        placeholder="Enter your city"
                      />
                    </div>
                    <div className="form-group">
                      <label>State *</label>
                      <input
                        type="text"
                        name="state"
                        value={formData.state}
                        onChange={handleInputChange}
                        placeholder="Enter your state"
                      />
                    </div>
                    <div className="button-group">
                      <button className="btn-save" onClick={handleSaveProfile} disabled={isLoading}>
                        {isLoading ? "Saving..." : "✓ Save Changes"}
                      </button>
                      <button className="btn-cancel" onClick={() => setIsEditing(false)} disabled={isLoading}>
                        ✕ Cancel
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* SECURITY TAB */}
          {activeTab === "security" && (
            <div className="tab-section">
              <h3>Change Password</h3>
              <div className="security-section">
                <div className="form-group">
                  <label>Current Password *</label>
                  <input
                    type="password"
                    name="currentPassword"
                    value={passwordData.currentPassword}
                    onChange={handlePasswordChange}
                    placeholder="Enter current password"
                  />
                </div>
                <div className="form-group">
                  <label>New Password *</label>
                  <input
                    type="password"
                    name="newPassword"
                    value={passwordData.newPassword}
                    onChange={handlePasswordChange}
                    placeholder="Min 6 chars"
                  />
                </div>
                <div className="form-group">
                  <label>Confirm New Password *</label>
                  <input
                    type="password"
                    name="confirmPassword"
                    value={passwordData.confirmPassword}
                    onChange={handlePasswordChange}
                    placeholder="Confirm new password"
                  />
                </div>
                <button className="btn-save" onClick={handleChangePassword} disabled={isLoading}>
                  {isLoading ? "Processing..." : "🔐 Change Password"}
                </button>
              </div>

              <div className="security-info">
                <h4>Security Tips</h4>
                <ul>
                  <li>Use a strong password with mix of uppercase, lowercase, numbers and symbols</li>
                  <li>Never share your password with anyone</li>
                  <li>Change your password regularly</li>
                </ul>
              </div>
            </div>
          )}

          {/* PREFERENCES TAB */}
          {activeTab === "preferences" && (
            <div className="tab-section">
              <h3>Notification Preferences</h3>
              <div className="preferences-section">
                <div className="preference-item">
                  <div className="preference-info">
                    <h4>Email Notifications</h4>
                    <p>Receive booking confirmations and updates via email</p>
                  </div>
                  <label className="toggle-switch">
                    <input
                      type="checkbox"
                      checked={notificationSettings.emailNotifications}
                      onChange={() => handleNotificationChange("emailNotifications")}
                    />
                    <span className="toggle-slider"></span>
                  </label>
                </div>

                <div className="preference-item">
                  <div className="preference-info">
                    <h4>SMS Notifications</h4>
                    <p>Receive booking updates via SMS</p>
                  </div>
                  <label className="toggle-switch">
                    <input
                      type="checkbox"
                      checked={notificationSettings.smsNotifications}
                      onChange={() => handleNotificationChange("smsNotifications")}
                    />
                    <span className="toggle-slider"></span>
                  </label>
                </div>

                <div className="preference-item">
                  <div className="preference-info">
                    <h4>Booking Updates</h4>
                    <p>Get notified about important booking changes</p>
                  </div>
                  <label className="toggle-switch">
                    <input
                      type="checkbox"
                      checked={notificationSettings.bookingUpdates}
                      onChange={() => handleNotificationChange("bookingUpdates")}
                    />
                    <span className="toggle-slider"></span>
                  </label>
                </div>

                <div className="preference-item">
                  <div className="preference-info">
                    <h4>Promotional Offers</h4>
                    <p>Receive exclusive deals and offers</p>
                  </div>
                  <label className="toggle-switch">
                    <input
                      type="checkbox"
                      checked={notificationSettings.promoOffers}
                      onChange={() => handleNotificationChange("promoOffers")}
                    />
                    <span className="toggle-slider"></span>
                  </label>
                </div>
              </div>
            </div>
          )}

          {/* ACCOUNT TAB */}
          {activeTab === "account" && (
            <div className="tab-section">
              <h3>Account Management</h3>
              <div className="account-section">
                <div className="account-item">
                  <div className="item-info">
                    <h4>Member Since</h4>
                    <p>{user.created_at ? new Date(user.created_at).toLocaleDateString() : "Recently"}</p>
                  </div>
                </div>

                <div className="account-item">
                  <div className="item-info">
                    <h4>Account Status</h4>
                    <p className="status-active">🟢 Active</p>
                  </div>
                </div>

                <div className="account-item">
                  <div className="item-info">
                    <h4>My Wallet Balance</h4>
                    <p>₹{user.wallet_balance || "0.00"}</p>
                  </div>
                </div>

                <hr className="divider" />

                <div className="logout-section">
                  <h4>Logout</h4>
                  <button className="btn-logout" onClick={handleLogout}>
                    🚪 Logout from this device
                  </button>
                </div>

                <hr className="divider" />

                <div className="delete-section">
                  <h4>Delete Account</h4>
                  <p className="warning">
                    ⚠️ This action is permanent and cannot be undone
                  </p>
                  <button className="btn-delete" onClick={handleDeleteAccount} disabled={isLoading}>
                    {isLoading ? "Deleting..." : "🗑️ Delete My Account"}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default UserProfile;
