import React, { useState } from "react";
import { loginUser } from "../api";
import { Link, useNavigate } from "react-router-dom";

const Login = ({ onLogin }) => {
  const [form, setForm] = useState({ email: "", password: "" });
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    const res = await loginUser(form);

    if (res.success) {
      onLogin(res.user);
      if (res.user.role === 'admin') {
        navigate("/admin-dashboard");
      } else {
        navigate("/dashboard");
      }
    } else {
      alert(res.message);
    }
  };

  return (
    <div className="login-container">
      <h2>Login</h2>
      <form onSubmit={submit}>

        <input
          type="email"
          placeholder="Email"
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
        />

        <input
          type="password"
          placeholder="Password"
          value={form.password}
          onChange={(e) => setForm({ ...form, password: e.target.value })}
        />

        <button className="btn">Login</button>
      </form>

      <p>
        Don't have an account? <Link to="/register">Register</Link>
      </p>
      <p style={{ marginTop: '5px' }}>
        <Link to="/forgot-password" style={{ color: 'rgba(255,255,255,0.7)', fontSize: '0.9em', textDecoration: 'none' }}>Forgot Password?</Link>
      </p>
      <p style={{ marginTop: '10px', fontSize: '0.9em' }}>
        <Link to="/pnr-status" style={{ color: 'var(--secondary)' }}>Check PNR Status</Link>
      </p>
    </div>
  );
};

export default Login;
