import React, { useState } from "react";
import { createBooking } from "../api";
import { useNavigate } from "react-router-dom";

const Payment = ({ user, trip, seats }) => {
  const [name, setName] = useState(user.full_name);
  const [method, setMethod] = useState("UPI");
  const navigate = useNavigate();

  const pay = async () => {
    const res = await createBooking({
      user_id: user.id,
      trip_id: trip.trip_id,
      passenger_name: name,
      seats,
      source: trip.source,
      destination: trip.destination
    });

    if (res.success) {
      alert(`Booking Successful! Your PNR is ${res.pnr}. Check My Bookings for details.`);
      navigate("/dashboard");
    } else {
      alert(res.message);
    }
  };

  return (
    <div className="payment">
      <h2>Payment</h2>

      <p><strong>Bus:</strong> {trip.bus_number} ({trip.description})</p>
      <p><strong>Route:</strong> {trip.source} → {trip.destination}</p>
      <p><strong>Seats:</strong> {seats.join(", ")}</p>

      <label>Passenger Name</label>
      <input value={name} onChange={(e) => setName(e.target.value)} />

      <label>Payment Method</label>
      <select value={method} onChange={(e) => setMethod(e.target.value)}>
        <option value="UPI">UPI</option>
        <option value="CARD">Card</option>
        <option value="NETBANKING">Net Banking</option>
      </select>

      <button className="btn" onClick={pay}>Pay & Book</button>
    </div>
  );
};

export default Payment;
