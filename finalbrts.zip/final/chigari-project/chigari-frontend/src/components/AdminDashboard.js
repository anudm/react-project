import React, { useEffect, useState } from "react";
import {
    getBuses, addBus, deleteBus,
    getAdminRoutes, addRoute, deleteRoute,
    getAdminTrips, addTrip, deleteTrip
} from "../api";
import { useNavigate } from "react-router-dom";

const AdminDashboard = ({ user, onChangeUser }) => {
    const [activeTab, setActiveTab] = useState('buses');
    const [buses, setBuses] = useState([]);
    const [routes, setRoutes] = useState([]);
    const [trips, setTrips] = useState([]);

    // Forms
    const [busForm, setBusForm] = useState({ bus_number: "", type: "NON-AC", total_seats: 40, description: "" });
    const [routeForm, setRouteForm] = useState({ source: "", destination: "", distance_km: "", estimated_duration: "" });
    const [tripForm, setTripForm] = useState({ bus_id: "", route_id: "", travel_date: "", travel_time: "08:00", price: "" });

    const navigate = useNavigate();

    useEffect(() => {
        if (!user) { navigate('/login'); return; }
        if (user.role !== 'admin') { navigate('/dashboard'); return; }
        loadAll();
        // eslint-disable-next-line
    }, [user, navigate]);

    const loadAll = () => {
        loadBuses();
        loadRoutes();
        loadTrips();
    };

    const loadBuses = async () => setBuses(await getBuses());
    const loadRoutes = async () => setRoutes(await getAdminRoutes());
    const loadTrips = async () => setTrips(await getAdminTrips());

    // Handlers
    const handleAddBus = async (e) => {
        e.preventDefault();
        try {
            const res = await addBus(busForm);
            if (res.success) { alert("Bus added!"); loadBuses(); setBusForm({ bus_number: "", type: "NON-AC", total_seats: 40, description: "" }); }
            else alert(res.message);
        } catch (err) {
            alert("Error adding bus: " + (err.response?.data?.message || err.message));
        }
    };

    const handleAddRoute = async (e) => {
        e.preventDefault();
        try {
            const res = await addRoute(routeForm);
            if (res.success) { alert("Route added!"); loadRoutes(); setRouteForm({ source: "", destination: "", distance_km: "", estimated_duration: "" }); }
            else alert(res.message);
        } catch (err) {
            alert("Error adding route: " + (err.response?.data?.message || err.message));
        }
    };

    const handleAddTrip = async (e) => {
        e.preventDefault();
        try {
            const res = await addTrip(tripForm);
            if (res.success) { alert("Trip scheduled!"); loadTrips(); setTripForm({ bus_id: "", route_id: "", travel_date: "", travel_time: "08:00", price: "" }); }
            else alert(res.message);
        } catch (err) {
            alert("Error adding trip: " + (err.response?.data?.message || err.message));
        }
    };

    const handleDelete = async (type, id) => {
        if (!window.confirm("Are you sure?")) return;
        try {
            let res;
            if (type === 'bus') res = await deleteBus(id);
            if (type === 'route') res = await deleteRoute(id);
            if (type === 'trip') res = await deleteTrip(id);

            if (res.success) {
                loadAll();
            } else {
                alert("Failed to delete: " + (res.message || "Unknown error"));
            }
        } catch (err) {
            alert("Error deleting item: " + (err.response?.data?.message || err.message));
        }
    };

    const handleLogout = () => { onChangeUser(null); navigate('/login'); };

    return (
        <div className="admin-container" style={{ padding: "40px", maxWidth: "1200px", margin: "0 auto" }}>
            <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
                <h1 style={{ color: 'var(--secondary)', textShadow: '0 0 10px var(--secondary)' }}>Admin Dashboard</h1>
                <button onClick={handleLogout} className="btn" style={{ background: 'var(--danger)', border: 'none' }}>Logout</button>
            </header>

            {/* Tabs */}
            <div style={{ display: 'flex', gap: '15px', marginBottom: '30px' }}>
                {['buses', 'routes', 'trips'].map(tab => (
                    <button
                        key={tab}
                        onClick={() => setActiveTab(tab)}
                        style={{
                            padding: '10px 25px',
                            background: activeTab === tab ? 'var(--primary)' : 'rgba(255,255,255,0.1)',
                            border: 'none',
                            borderRadius: '30px',
                            color: 'white',
                            cursor: 'pointer',
                            textTransform: 'uppercase',
                            fontWeight: 'bold',
                            letterSpacing: '1px',
                            transition: 'all 0.3s ease'
                        }}
                    >
                        {tab}
                    </button>
                ))}
            </div>

            {/* BUSES TAB */}
            {activeTab === 'buses' && (
                <div>
                    <div className="glass-card" style={cardStyle}>
                        <h2 style={{ marginBottom: '20px', color: 'var(--primary)' }}>Add New Bus</h2>
                        <form onSubmit={handleAddBus} style={gridFormStyle}>
                            <input placeholder="Bus No (KA-01-F-1234)" value={busForm.bus_number} onChange={e => setBusForm({ ...busForm, bus_number: e.target.value })} required style={inputStyle} />
                            <select value={busForm.type} onChange={e => setBusForm({ ...busForm, type: e.target.value })} style={inputStyle}>
                                <option>NON-AC</option><option>AC</option><option>SLEEPER</option><option>VOLVO</option>
                            </select>
                            <input type="number" placeholder="Seats" value={busForm.total_seats} onChange={e => setBusForm({ ...busForm, total_seats: e.target.value })} required style={inputStyle} />
                            <input placeholder="Description" value={busForm.description} onChange={e => setBusForm({ ...busForm, description: e.target.value })} style={inputStyle} />
                            <button className="btn" style={{ gridColumn: '1 / -1' }}>Add Bus</button>
                        </form>
                    </div>
                    <div className="list-grid" style={listGridStyle}>
                        {buses.map(bus => (
                            <div key={bus.id} className="glass-card" style={itemCardStyle}>
                                <h3>{bus.bus_number}</h3>
                                <p>Type: <span style={{ color: 'var(--secondary)' }}>{bus.type}</span></p>
                                <p>Seats: {bus.total_seats}</p>
                                <button onClick={() => handleDelete('bus', bus.id)} style={deleteBtnStyle}>Remove</button>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* ROUTES TAB */}
            {activeTab === 'routes' && (
                <div>
                    <div className="glass-card" style={cardStyle}>
                        <h2 style={{ marginBottom: '20px', color: 'var(--primary)' }}>Add New Route</h2>
                        <form onSubmit={handleAddRoute} style={gridFormStyle}>
                            <input placeholder="Source (e.g. Hubballi)" value={routeForm.source} onChange={e => setRouteForm({ ...routeForm, source: e.target.value })} required style={inputStyle} />
                            <input placeholder="Destination (e.g. Goa)" value={routeForm.destination} onChange={e => setRouteForm({ ...routeForm, destination: e.target.value })} required style={inputStyle} />
                            <input type="number" placeholder="Distance (km)" value={routeForm.distance_km} onChange={e => setRouteForm({ ...routeForm, distance_km: e.target.value })} required style={inputStyle} />
                            <input placeholder="Duration (e.g. 5 hours)" value={routeForm.estimated_duration} onChange={e => setRouteForm({ ...routeForm, estimated_duration: e.target.value })} required style={inputStyle} />
                            <button className="btn" style={{ gridColumn: '1 / -1' }}>Add Route</button>
                        </form>
                    </div>
                    <div className="list-grid" style={listGridStyle}>
                        {routes.map(r => (
                            <div key={r.id} className="glass-card" style={itemCardStyle}>
                                <h3>{r.source} ➝ {r.destination}</h3>
                                <p>{r.distance_km} km</p>
                                <p>{r.estimated_duration}</p>
                                <button onClick={() => handleDelete('route', r.id)} style={deleteBtnStyle}>Remove</button>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* TRIPS TAB */}
            {activeTab === 'trips' && (
                <div>
                    <div className="glass-card" style={cardStyle}>
                        <h2 style={{ marginBottom: '20px', color: 'var(--primary)' }}>Schedule New Trip</h2>
                        <form onSubmit={handleAddTrip} style={gridFormStyle}>
                            <select value={tripForm.bus_id} onChange={e => setTripForm({ ...tripForm, bus_id: e.target.value })} required style={inputStyle}>
                                <option value="">Select Bus</option>
                                {buses.map(b => <option key={b.id} value={b.id}>{b.bus_number} ({b.type})</option>)}
                            </select>
                            <select value={tripForm.route_id} onChange={e => setTripForm({ ...tripForm, route_id: e.target.value })} required style={inputStyle}>
                                <option value="">Select Route</option>
                                {routes.map(r => <option key={r.id} value={r.id}>{r.source} ➝ {r.destination}</option>)}
                            </select>
                            <input type="date" value={tripForm.travel_date} onChange={e => setTripForm({ ...tripForm, travel_date: e.target.value })} required style={inputStyle} />
                            <input type="time" value={tripForm.travel_time} onChange={e => setTripForm({ ...tripForm, travel_time: e.target.value })} required style={inputStyle} />
                            <input type="number" placeholder="Price (INR)" value={tripForm.price} onChange={e => setTripForm({ ...tripForm, price: e.target.value })} required style={inputStyle} />
                            <button className="btn" style={{ gridColumn: '1 / -1' }}>Schedule Trip</button>
                        </form>
                    </div>
                    <div className="list-grid" style={listGridStyle}>
                        {trips.map(t => (
                            <div key={t.id} className="glass-card" style={itemCardStyle}>
                                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <span style={{ fontSize: '0.9em', color: 'var(--secondary)' }}>{new Date(t.travel_date).toDateString()} @ {t.travel_time}</span>
                                    <span style={{ fontWeight: 'bold', color: 'var(--success)' }}>₹{t.price}</span>
                                </div>
                                <h3 style={{ margin: '10px 0' }}>{t.source} ➝ {t.destination}</h3>
                                <p style={{ fontSize: '0.9em' }}>Bus: {t.bus_number} ({t.bus_type})</p>
                                <button onClick={() => handleDelete('trip', t.id)} style={deleteBtnStyle}>Cancel Trip</button>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

// Styles
const cardStyle = {
    padding: '30px', marginBottom: '40px', background: 'var(--glass-bg)',
    borderRadius: '20px', border: '1px solid var(--glass-border)',
    boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.37)'
};
const gridFormStyle = { display: "grid", gap: "20px", gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))' };
const inputStyle = {
    padding: '12px', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.2)',
    background: 'rgba(0,0,0,0.3)', color: 'white', fontSize: '1em', outline: 'none'
};
const listGridStyle = { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '25px' };
const itemCardStyle = {
    padding: "20px", border: "1px solid var(--glass-border)", borderRadius: "15px",
    background: 'rgba(255,255,255,0.05)', position: 'relative'
};
const deleteBtnStyle = {
    backgroundColor: "transparent", color: "var(--danger)", border: "1px solid var(--danger)",
    padding: "8px 15px", borderRadius: "50px", cursor: "pointer", marginTop: '15px', width: '100%'
};

export default AdminDashboard;
