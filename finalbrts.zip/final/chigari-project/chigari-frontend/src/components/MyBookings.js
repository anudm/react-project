import React, { useEffect, useState } from "react";
import { getUserBookings, cancelBooking } from "../api";
import { useNavigate } from "react-router-dom";

const MyBookings = ({ user }) => {
    const [bookings, setBookings] = useState([]);
    const navigate = useNavigate();
    const [loading, setLoading] = useState(true);

    const load = async () => {
        setLoading(true);
        const res = await getUserBookings(user.id);
        if (res.success) {
            setBookings(res.bookings);
        }
        setLoading(false);
    };

    useEffect(() => {
        load();
        // eslint-disable-next-line
    }, [user]);

    const handleCancel = async (id) => {
        if (!window.confirm("Are you sure you want to cancel this ticket?")) return;
        const res = await cancelBooking(id);
        if (res.success) {
            alert("Ticket Cancelled Successfully.");
            load(); // Reload
        } else {
            alert("Failed to cancel");
        }
    };

    return (
        <div className="bookings-page">
            <style>{`
        .bookings-page {
          min-height: 100vh;
          padding: 100px 20px 40px;
          display: flex;
          flex-direction: column;
          align-items: center;
        }
        .booking-card {
          background: rgba(15, 23, 42, 0.6);
          backdrop-filter: blur(12px);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 16px;
          padding: 20px;
          margin-bottom: 20px;
          width: 90%;
          max-width: 600px;
          color: #fff;
          display: flex;
          justify-content: space-between;
          align-items: center;
          animation: slideUpFade 0.5s ease-out;
          transition: transform 0.2s;
        }
        .booking-card:hover {
          transform: scale(1.02);
          border-color: var(--primary);
        }
        .b-h2 {
          text-align: center;
          margin-bottom: 30px;
          color: var(--text-bright);
        }
        .b-time { font-size: 0.9em; color: #e2e8f0; }
        .b-route { font-size: 1.2em; font-weight: bold; color: #00eaff; margin: 5px 0; }
        .b-seat { background: #334155; padding: 5px 10px; border-radius: 6px; color: #fff; text-align: center; }
        .b-pnr { font-size: 0.8em; color: var(--secondary); margin-bottom: 5px; }
        .cancel-btn {
          margin-top: 5px;
          background: #ef4444;
          color: white;
          border: none;
          padding: 5px 10px;
          font-size: 0.8em;
          border-radius: 4px;
          cursor: pointer;
        }
        .cancel-btn:hover { background: #dc2626; }
        .status-cancelled { color: #ef4444; font-weight: bold; border: 1px solid #ef4444; padding: 2px 5px; border-radius: 4px; }
      `}</style>

            <h2 className="b-h2">My Bookings</h2>

            <button className="btn" onClick={() => navigate("/dashboard")} style={{ marginBottom: "20px" }}>
                Back to Dashboard
            </button>

            {loading ? <p>Loading...</p> : bookings.length === 0 ? (
                <p>No bookings found.</p>
            ) : (
                <>
                    {bookings.filter(b => b.status === 'BOOKED').map((b) => (
                        <div key={b.id} className="booking-card">
                            <div>
                                <div className="b-pnr">PNR: {b.pnr || 'N/A'}</div>
                                <div className="b-time">{new Date(b.travel_date).toLocaleDateString()} at {b.travel_time}</div>
                                <div className="b-route">{b.source} → {b.destination}</div>
                                <div style={{ color: '#fff' }}>Bus: {b.bus_number}</div>
                                <div style={{ marginTop: '5px', fontSize: '0.9em', color: '#ffffff' }}>Passenger: {b.passenger_name}</div>
                            </div>
                            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end' }}>
                                <div className="b-seat">
                                    Seat #{b.seat_number}
                                </div>
                                <button className="cancel-btn" onClick={() => handleCancel(b.id)}>
                                    Cancel Ticket
                                </button>
                            </div>
                        </div>
                    ))}

                    {bookings.filter(b => b.status === 'CANCELLED').length > 0 && (
                        <>
                            <div className="divider" style={{ width: '90%', height: '1px', background: 'rgba(255,255,255,0.2)', margin: '20px 0' }}></div>
                            <h3 style={{ color: '#aaa', marginBottom: '20px' }}>Cancelled Bookings</h3>
                            {bookings.filter(b => b.status === 'CANCELLED').map((b) => (
                                <div key={b.id} className="booking-card" style={{ opacity: 0.6, borderStyle: 'dashed' }}>
                                    <div>
                                        <div className="b-pnr">PNR: {b.pnr || 'N/A'}</div>
                                        <div className="b-time">{new Date(b.travel_date).toLocaleDateString()} at {b.travel_time}</div>
                                        <div className="b-route">{b.source} → {b.destination}</div>
                                        <div style={{ color: '#fff' }}>Bus: {b.bus_number}</div>
                                    </div>
                                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end' }}>
                                        <div className="b-seat">
                                            Seat #{b.seat_number}
                                        </div>
                                        <div style={{ marginTop: '10px' }} className="status-cancelled">CANCELLED</div>
                                    </div>
                                </div>
                            ))}
                        </>
                    )}
                </>
            )}
        </div>
    );
};

export default MyBookings;
