import React, { useState } from "react";
import { checkPNR } from "../api";

const PNRStatus = () => {
    const [pnr, setPnr] = useState("");
    const [result, setResult] = useState(null);
    const [error, setError] = useState("");

    const search = async (e) => {
        e.preventDefault();
        setError("");
        setResult(null);
        if (!pnr) return;

        const res = await checkPNR(pnr);
        if (res && res.length > 0) {
            setResult(res);
        } else {
            setError("Invalid PNR or No Booking Found");
        }
    };

    return (
        <div className="pnr-page">
            <style>{`
                .pnr-page {
                    min-height: 100vh;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    padding-top: 150px;
                }
                .pnr-card {
                    background: rgba(15, 23, 42, 0.8);
                    padding: 30px;
                    border-radius: 12px;
                    border: 1px solid var(--primary);
                    width: 100%;
                    max-width: 500px;
                    text-align: center;
                }
                .pnr-input {
                    padding: 12px;
                    width: 70%;
                    background: #fff;
                    color: #000;
                    border-radius: 6px;
                    border: none;
                    margin-right: 10px;
                }
                .result-box {
                    margin-top: 30px;
                    width: 90%;
                    max-width: 600px;
                }
                .r-item {
                    background: rgba(255,255,255,0.1);
                    margin: 10px 0;
                    padding: 15px;
                    border-radius: 8px;
                    display: flex;
                    justify-content: space-between;
                }
            `}</style>

            <h2 style={{ textShadow: '0 0 20px cyan', marginBottom: '30px' }}>Track Your Ticket (PNR)</h2>

            <form className="pnr-card" onSubmit={search}>
                <input
                    className="pnr-input"
                    placeholder="Enter PNR e.g. PNR123456"
                    value={pnr}
                    onChange={(e) => setPnr(e.target.value)}
                />
                <button className="btn">Check</button>
            </form>

            {error && <p style={{ color: 'red', marginTop: '20px', background: 'rgba(0,0,0,0.5)', padding: '5px 10px' }}>{error}</p>}

            {result && (
                <div className="result-box">
                    {result.map((ticket, i) => (
                        <div key={i} className="r-item">
                            <div>
                                <div style={{ color: 'cyan', fontWeight: 'bold' }}>{ticket.seat_number} - {ticket.passenger_name}</div>
                                <div style={{ fontSize: '0.9em' }}>{ticket.source} → {ticket.destination}</div>
                                <div style={{ fontSize: '0.8em', color: '#ccc' }}>{new Date(ticket.travel_date).toDateString()}</div>
                            </div>
                            <div style={{
                                fontWeight: 'bold',
                                color: ticket.status === 'CANCELLED' ? 'red' : 'lightgreen'
                            }}>
                                {ticket.status}
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default PNRStatus;
