export const PLACES = [
  "Hubli Railway Station",
  "HDMC Hosur",
  "Hosur Cross",
  "KIMS",
  "Vidyanagar",
  "BVB",
  "Unkal Cross",
  "Unkal",
  "Unkal Lake",
  "APMC",
  "Bairidevarikoppa",
  "Shantiniketan",
  "Navanagar",
  "Iskon Temple",
  "Rayapur",
  "Sattura",
  "Toll Naka",
  "Korta Circle",
  "NTTF",
  "Jubli Circle",
  "Dharawad New Bustand"
];

export const BUS_NUMBERS = [
  { value: "100D", label: "100D - Main Route" },
  { value: "200A", label: "200A - AC Express" },
  { value: "201", label: "201 - Non Stop" }
];
