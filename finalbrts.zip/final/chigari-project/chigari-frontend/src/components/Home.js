// src/components/Home.js
import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function Home() {
  const navigate = useNavigate();

  // Parallax
  useEffect(() => {
    const handler = (e) => {
      const root = document.getElementById("home-hero-root");
      if (!root) return;
      const x = (e.clientX / window.innerWidth - 0.5) * 15;
      const y = (e.clientY / window.innerHeight - 0.5) * 12;
      root.style.setProperty("--mx", `${x}px`);
      root.style.setProperty("--my", `${y}px`);
    };
    window.addEventListener("mousemove", handler);
    return () => window.removeEventListener("mousemove", handler);
  }, []);

  const bg = process.env.PUBLIC_URL + "/Chigari-Bus-Hubli-Dharwad-Infra.jpg";

  return (
    <div
      id="home-hero-root"
      style={{
        "--bgurl": `url(${bg})`,
      }}
    >
      <div className="hero-content">
        <h1 className="title">Chigari Connect</h1>
        <p className="subtitle">Hubballi-Dharwad Smart City</p>

        <button className="btn" onClick={() => navigate("/dashboard")}>
          Go to Dashboard
        </button>
      </div>
    </div>
  );
}
