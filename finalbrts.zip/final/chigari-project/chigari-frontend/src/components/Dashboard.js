// src/components/Dashboard.js
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import AutocompleteInput from "./AutocompleteInput";
import { PLACES } from "./places";
import { searchTrips } from "../api";
import UserProfile from "./UserProfile";

const Dashboard = ({ user, onSelectTrip, onChangeUser }) => {
  const [source, setSource] = useState("");
  const [destination, setDestination] = useState("");
  const [date, setDate] = useState("");
  const [trips, setTrips] = useState([]); // Store search results
  const [searched, setSearched] = useState(false); // Track if search was performed
  const [wallet, setWallet] = useState(500); // Mock wallet balance
  const [showWallet, setShowWallet] = useState(false);
  const [showProfile, setShowProfile] = useState(false);

  const navigate = useNavigate();

  useEffect(() => {
    // Load all trips initially to show "All Routes" like old app
    searchBus({ preventDefault: () => { } });
  }, []);

  const searchBus = async (e) => {
    if (e) e.preventDefault();

    // Call API to get real trips
    setSearched(false);
    setTrips([]);
    try {
      // If no filters, backend returns all or we can send empty params
      const results = await searchTrips({ source, destination, date });
      setTrips(results);
    } catch (err) {
      console.error(err);
      // alert("Failed to fetch trips"); // suppress initial load error
    } finally {
      setSearched(true);
    }
  };

  const handleSelectTrip = (trip) => {
    onSelectTrip(trip);
    navigate("/seats");
  };

  const logout = () => {
    localStorage.clear();
    navigate("/login");
  };

  return (
    <div className="dashboard-hero">

      {/* Glow Heading */}
      <h2 className="dashboard-title">Welcome, {user.full_name}</h2>

      {/* Navigation */}
      <div className="dashboard-nav">
        <button className="nav-btn profile-btn" onClick={() => setShowProfile(true)}>
          👤 {user.full_name.split(" ")[0]}
        </button>
        <button className="nav-btn" onClick={() => setShowWallet(!showWallet)}>
          ₹ {wallet}
        </button>
        <button className="nav-btn" onClick={() => navigate("/my-bookings")}>
          My Bookings
        </button>
        <button className="nav-btn danger" onClick={logout}>
          Logout
        </button>
      </div>

      {/* User Profile Modal */}
      {showProfile && (
        <UserProfile 
          user={user} 
          onChangeUser={onChangeUser}
          onClose={() => setShowProfile(false)} 
        />
      )}

      <div className="dashboard-content">

        {/* Wallet Modal */}
        {showWallet && (
          <div className="wallet-card">
            <h3>My Wallet</h3>
            <div className="w-bal">₹ {wallet}</div>
            <p>Use Chigari Pay for faster bookings.</p>
            <div className="w-actions">
              <button className="btn-sm" onClick={() => setWallet(wallet + 100)}>+ ₹100</button>
              <button className="btn-sm" onClick={() => setWallet(wallet + 500)}>+ ₹500</button>
            </div>
          </div>
        )}

        {/* Search Form */}
        <form className="dashboard-card" onSubmit={searchBus}>
          <div className="span-2" style={{ textAlign: 'center', marginBottom: '10px' }}>
            <h3>Find Your Bus</h3>
          </div>

          <AutocompleteInput
            label="Source"
            value={source}
            onChange={setSource}
            options={PLACES}
          />

          <AutocompleteInput
            label="Destination"
            value={destination}
            onChange={setDestination}
            options={PLACES}
          />

          <div>
            <label>Date</label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
            />
          </div>

          <button className="btn span-2" style={{ marginTop: '20px' }}>
            Search Buses
          </button>
        </form>

        {/* Results Area */}
        {searched && (
          <div className="results-container">
            <h3>Available Trips</h3>

            {trips.length === 0 ? (
              <p className="no-trips">No trips found for this route/date.</p>
            ) : (
              <div className="trips-grid">
                {trips.map(trip => (
                  <div key={trip.trip_id} className="trip-card">
                    <div className="t-info">
                      <div className="t-time">{trip.travel_time}</div>
                      <div className="t-route">{trip.source} → {trip.destination}</div>
                      <div className="t-bus">{trip.bus_number}</div>
                      <div className="t-desc">{trip.description}</div>
                    </div>
                    <div className="t-price">
                      ₹ {trip.price}
                    </div>
                    <button className="btn-sm" onClick={() => handleSelectTrip(trip)}>
                      Select
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

      </div>

      {/* Inline Styles for Results */}
      <style>{`
        .dashboard-content {
          width: 100%;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 40px;
          padding-bottom: 50px;
        }
        .results-container {
          width: 90%;
          max-width: 800px;
          animation: slideUp 0.8s ease-out;
        }
        .results-container h3 {
          text-align: center;
          margin-bottom: 20px;
          color: var(--primary);
        }
        .no-trips {
          text-align: center;
          font-size: 1.2rem;
          color: var(--text-dim);
        }
        .trips-grid {
          display: grid;
          gap: 15px;
        }
        .trip-card {
          display: flex;
          justify-content: space-between;
          align-items: center;
          background: rgba(20, 20, 50, 0.4); /* Darker glass */
          border: 1px solid rgba(255, 0, 127, 0.3); /* Pinkish border */
          padding: 20px;
          border-radius: 12px;
          transition: 0.3s;
          backdrop-filter: blur(10px);
        }
        .trip-card:hover {
          border-color: var(--secondary); /* Cyan on hover */
          box-shadow: 0 0 20px rgba(0, 234, 255, 0.3);
          transform: translateY(-5px);
        }
        .t-time { font-size: 1.8rem; font-weight: 800; color: #ffffff; text-shadow: 0 0 10px rgba(255,255,255,0.5); }
        .t-route { font-size: 1.1rem; color: #ffffff; font-weight: bold; margin: 4px 0; }
        .t-bus { color: #ffffff; font-weight: 500; font-size: 0.95rem; }
        .t-desc { font-size: 0.9rem; color: #ffffff; }
        .btn-sm {
          padding: 8px 16px;
          background: var(--primary);
          border: none;
          border-radius: 6px;
          font-weight: bold;
          cursor: pointer;
        }
        .btn-sm:hover {
  background: #fff;
  box-shadow: 0 0 10px #fff;
}
.wallet-card {
  position: absolute;
  top: 80px;
  right: 30px;
  background: rgba(15, 23, 42, 0.95);
  border: 1px solid var(--success);
  padding: 20px;
  border-radius: 12px;
  z-index: 20;
  width: 250px;
  text-align: center;
  box-shadow: 0 0 30px rgba(16, 185, 129, 0.3);
  animation: fadeIn 0.3s ease;
}
.w-bal {
  font-size: 2.5rem;
  font-weight: 800;
  color: var(--success);
  margin: 10px 0;
}
.w-actions {
  display: flex;
  gap: 10px;
  justify-content: center;
  margin-top: 15px;
}        
      `}</style>
    </div>
  );
};

export default Dashboard;
