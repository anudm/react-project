import React, { useState } from "react";
import { Link } from "react-router-dom";

const ForgotPassword = () => {
    const [email, setEmail] = useState("");
    const [submitted, setSubmitted] = useState(false);

    const handleSubmit = (e) => {
        e.preventDefault();
        // Here you would typically call an API to send a reset email
        // For now, we'll simulate a successful request
        setSubmitted(true);
    };

    return (
        <div className="login-container">
            <h2>Forgot Password</h2>
            {!submitted ? (
                <form onSubmit={handleSubmit}>
                    <p style={{ marginBottom: '15px', color: '#666' }}>
                        Enter your email address and we'll send you instructions to reset your password.
                    </p>
                    <input
                        type="email"
                        placeholder="Enter your email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                    <button className="btn">Send Reset Link</button>
                    <div style={{ marginTop: '15px', textAlign: 'center' }}>
                        <Link to="/login" style={{ color: 'var(--secondary)' }}>Back to Login</Link>
                    </div>
                </form>
            ) : (
                <div style={{ textAlign: "center" }}>
                    <h3 style={{ color: "green" }}>Check your email</h3>
                    <p>We've sent password reset instructions to <strong>{email}</strong>.</p>
                    <div style={{ marginTop: '20px' }}>
                        <Link to="/login" className="btn" style={{ textDecoration: 'none', display: 'inline-block' }}>Back to Login</Link>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ForgotPassword;
