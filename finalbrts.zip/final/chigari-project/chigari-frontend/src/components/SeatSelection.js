import React, { useEffect, useState } from "react";
import { getBookedSeats } from "../api";
import { useNavigate } from "react-router-dom";

const TOTAL_SEATS = 40;

const SeatSelection = ({ user, trip, selectedSeats, setSelectedSeats }) => {
  const [booked, setBooked] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    async function load() {
      const res = await getBookedSeats(trip.trip_id);
      setBooked(res.map(Number));
    }
    load();
  }, [trip]);

  const toggle = (seat) => {
    if (booked.includes(seat)) return;

    if (selectedSeats.includes(seat)) {
      setSelectedSeats(selectedSeats.filter((s) => s !== seat));
    } else {
      setSelectedSeats([...selectedSeats, seat]);
    }
  };

  return (
    <div className="seats">
      <h2>
        Select Seats – {trip.bus_number} ({trip.source} → {trip.destination})
      </h2>

      <div className="grid">
        {Array.from({ length: TOTAL_SEATS }, (_, i) => i + 1).map((seat) => {
          const isBooked = booked.includes(seat);
          const isSelected = selectedSeats.includes(seat);

          return (
            <button
              key={seat}
              className={`seat ${isBooked ? "booked" : ""} ${isSelected ? "selected" : ""}`}
              disabled={isBooked}
              onClick={() => toggle(seat)}
            >
              {seat}
            </button>
          );
        })}
      </div>

      <button className="btn" onClick={() => navigate("/payment")}>
        Continue to Payment
      </button>
    </div>
  );
};

export default SeatSelection;
