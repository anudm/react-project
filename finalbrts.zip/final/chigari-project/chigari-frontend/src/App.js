import React, { useState } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Home from "./components/Home";
import Login from "./components/Login";
import Register from "./components/Register";
import Dashboard from "./components/Dashboard";
import SeatSelection from "./components/SeatSelection";
import Payment from "./components/Payment";
import MyBookings from "./components/MyBookings";
import PNRStatus from "./components/PNRStatus";
import AdminDashboard from "./components/AdminDashboard";
import ForgotPassword from "./components/ForgotPassword";

function App() {
  const [user, setUser] = useState(null);
  const [selectedTrip, setSelectedTrip] = useState(null);
  const [selectedSeats, setSelectedSeats] = useState([]);

  return (
    <Routes>
      <Route path="/" element={<Home user={user} />} />
      <Route path="/login" element={<Login onLogin={setUser} />} />
      <Route path="/register" element={<Register />} />
      <Route path="/pnr-status" element={<PNRStatus />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/admin-dashboard" element={<AdminDashboard user={user} onChangeUser={setUser} />} />

      <Route
        path="/dashboard"
        element={
          user ? (
            <Dashboard user={user} onSelectTrip={setSelectedTrip} onChangeUser={setUser} />
          ) : (
            <Navigate to="/login" />
          )
        }
      />

      <Route
        path="/seats"
        element={
          user && selectedTrip ? (
            <SeatSelection
              user={user}
              trip={selectedTrip}
              selectedSeats={selectedSeats}
              setSelectedSeats={setSelectedSeats}
            />
          ) : (
            <Navigate to="/dashboard" />
          )
        }
      />

      <Route
        path="/payment"
        element={
          user && selectedSeats.length > 0 ? (
            <Payment user={user} trip={selectedTrip} seats={selectedSeats} />
          ) : (
            <Navigate to="/dashboard" />
          )
        }
      />

      <Route
        path="/my-bookings"
        element={
          user ? (
            <MyBookings user={user} />
          ) : (
            <Navigate to="/login" />
          )
        }
      />
    </Routes>
  );
}

export default App;
