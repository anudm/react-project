const pool = require("./db");
const bcrypt = require("bcryptjs");

async function updateDB() {
    try {
        console.log("Updating database schema...");

        // 1. Add role column to users table
        try {
            await pool.query("ALTER TABLE users ADD COLUMN role VARCHAR(20) DEFAULT 'user'");
            console.log("Added role column to users table.");
        } catch (e) {
            if (e.code === 'ER_DUP_FIELDNAME') {
                console.log("Role column already exists.");
            } else {
                console.error("Error adding role column:", e.message);
            }
        }

        // 2. Create an admin user if not exists
        const [rows] = await pool.query("SELECT * FROM users WHERE email='admin@chigari.com'");
        if (rows.length === 0) {
            const hash = await bcrypt.hash("admin123", 10);
            await pool.query(
                "INSERT INTO users (full_name, email, password, wallet_balance, role) VALUES (?, ?, ?, ?, ?)",
                ["System Admin", "admin@chigari.com", hash, 0.00, "admin"]
            );
            console.log("Admin user created (email: admin@chigari.com, pass: admin123)");
        } else {
            console.log("Admin user already exists.");
            // Ensure role is admin
            await pool.query("UPDATE users SET role='admin' WHERE email='admin@chigari.com'");
        }

        console.log("Database update complete.");
        process.exit();
    } catch (e) {
        console.error("Database update failed:", e);
        process.exit(1);
    }
}

updateDB();
