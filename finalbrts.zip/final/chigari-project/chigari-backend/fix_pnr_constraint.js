const pool = require('./db');

const fix = async () => {
    console.log("Checking for UNIQUE constraint on 'pnr' in 'bookings' table...");
    try {
        const [indexes] = await pool.query("SHOW INDEX FROM bookings WHERE Column_name = 'pnr'");

        let foundUnique = false;
        for (let idx of indexes) {
            // Non_unique is 0 if the index is unique
            if (idx.Non_unique === 0) {
                console.log(`Found UNIQUE index: ${idx.Key_name}`);
                await pool.query(`ALTER TABLE bookings DROP INDEX ${idx.Key_name}`);
                console.log(`Index ${idx.Key_name} dropped.`);
                foundUnique = true;
            }
        }

        if (!foundUnique) {
            console.log("No UNIQUE constraint found on 'pnr'.");
        } else {
            console.log("Successfully removed UNIQUE constraint on 'pnr'.");
        }

    } catch (e) {
        console.error("Error:", e.message);
    } finally {
        // We must manually close the pool to exit the script if we imported it
        // pool.end() might not be available on pool object directly in mysql2/promise if using createPool? 
        // Actually pool.end() exists.
        await pool.end();
    }
};

fix();
