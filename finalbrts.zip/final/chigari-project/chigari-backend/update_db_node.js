const mysql = require('mysql2/promise');

const update = async () => {
    console.log("Updating Database with User's Specific Stops...");
    const conn = await mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'chigari_app'
    });

    try {
        // 1. Clean existing data
        await conn.query("DELETE FROM bookings");
        await conn.query("DELETE FROM trips");
        await conn.query("DELETE FROM routes");

        // Drop stops table if exists to rebuild
        await conn.query("DROP TABLE IF EXISTS stops");

        console.log("Old data cleared.");

        // 2. Create Stops Table
        await conn.query(`
            CREATE TABLE IF NOT EXISTS stops (
                id INT AUTO_INCREMENT PRIMARY KEY,
                stop_name VARCHAR(255) UNIQUE NOT NULL
            )
        `);

        // 3. Insert The Specific List Provided by User
        const stops = [
            "Hubli Railway Station", "HDMC Hosur", "Hosur Cross", "KIMS",
            "Vidyanagar", "BVB", "Unkal Cross", "Unkal", "Unkal Lake",
            "APMC", "Bairidevarikoppa", "Shantiniketan", "Navanagar",
            "Iskon Temple", "Rayapur", "Sattura", "Toll Naka",
            "Korta Circle", "NTTF", "Jubli Circle", "Dharawad New Bustand"
        ];

        for (const s of stops) {
            await conn.query("INSERT IGNORE INTO stops (stop_name) VALUES (?)", [s]);
        }
        console.log("Stops inserted into DB.");

        // 4. Insert Main Corridor Routes (Derived from the end-points of the list)
        // Main Route: Hubli Railway Station <-> Dharawad New Bustand
        await conn.query(`
            INSERT INTO routes (id, source, destination, distance_km, estimated_duration) VALUES 
            (1, 'Hubli Railway Station', 'Dharawad New Bustand', 22, '45 mins'),
            (2, 'Dharawad New Bustand', 'Hubli Railway Station', 22, '45 mins')
        `);

        // 5. Insert Trips (Scheduled Buses on this corridor)
        const trips = [
            // Morning Rush
            [1, 1, 'Hubli Railway Station', 'Dharawad New Bustand', '07:00', 35.00],
            [2, 1, 'Hubli Railway Station', 'Dharawad New Bustand', '07:15', 25.00],
            [1, 1, 'Hubli Railway Station', 'Dharawad New Bustand', '07:30', 35.00],
            [3, 1, 'Hubli Railway Station', 'Dharawad New Bustand', '08:00', 30.00],
            [1, 1, 'Hubli Railway Station', 'Dharawad New Bustand', '08:15', 35.00],
            [2, 1, 'Hubli Railway Station', 'Dharawad New Bustand', '08:30', 25.00],
            [1, 1, 'Hubli Railway Station', 'Dharawad New Bustand', '09:00', 35.00],

            // Mid Day
            [3, 1, 'Hubli Railway Station', 'Dharawad New Bustand', '10:00', 30.00],
            [1, 1, 'Hubli Railway Station', 'Dharawad New Bustand', '11:00', 35.00],
            [2, 1, 'Hubli Railway Station', 'Dharawad New Bustand', '12:00', 25.00],
            [3, 1, 'Hubli Railway Station', 'Dharawad New Bustand', '13:00', 30.00],

            // Evening Return
            [1, 2, 'Dharawad New Bustand', 'Hubli Railway Station', '16:00', 35.00],
            [2, 2, 'Dharawad New Bustand', 'Hubli Railway Station', '17:00', 25.00],
            [3, 2, 'Dharawad New Bustand', 'Hubli Railway Station', '17:30', 30.00],
            [1, 2, 'Dharawad New Bustand', 'Hubli Railway Station', '18:00', 35.00],
            [2, 2, 'Dharawad New Bustand', 'Hubli Railway Station', '18:30', 25.00],
            [1, 2, 'Dharawad New Bustand', 'Hubli Railway Station', '19:00', 35.00]
        ];

        for (const t of trips) {
            await conn.query(`
                INSERT INTO trips (bus_id, route_id, source, destination, travel_date, travel_time, price) 
                VALUES (?, ?, ?, ?, CURDATE(), ?, ?)
             `, t);
        }
        console.log("Scheduled Trips inserted.");

    } catch (e) {
        console.error(e);
    } finally {
        conn.end();
    }
};

update();
