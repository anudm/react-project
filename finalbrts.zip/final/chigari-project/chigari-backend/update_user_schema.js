const pool = require('./db');

const updateSchema = async () => {
    console.log("Updating Users Table Schema...");
    const conn = await pool.getConnection();
    try {
        // Add gender
        try {
            await conn.query("ALTER TABLE users ADD COLUMN gender VARCHAR(20) DEFAULT 'Not Specified'");
            console.log("Added column: gender");
        } catch (e) {
            if (!e.message.includes("Duplicate column")) console.error("Error adding gender:", e.message);
        }

        // Add date_of_birth
        try {
            await conn.query("ALTER TABLE users ADD COLUMN date_of_birth DATE DEFAULT NULL");
            console.log("Added column: date_of_birth");
        } catch (e) {
            if (!e.message.includes("Duplicate column")) console.error("Error adding date_of_birth:", e.message);
        }

        // Add city
        try {
            await conn.query("ALTER TABLE users ADD COLUMN city VARCHAR(100) DEFAULT NULL");
            console.log("Added column: city");
        } catch (e) {
            if (!e.message.includes("Duplicate column")) console.error("Error adding city:", e.message);
        }

        // Add state
        try {
            await conn.query("ALTER TABLE users ADD COLUMN state VARCHAR(100) DEFAULT NULL");
            console.log("Added column: state");
        } catch (e) {
            if (!e.message.includes("Duplicate column")) console.error("Error adding state:", e.message);
        }

        console.log("Schema update complete.");

    } catch (e) {
        console.error("Critical Error:", e);
    } finally {
        conn.release();
        // Close pool to allow script to exit
        pool.end();
    }
};

updateSchema();
