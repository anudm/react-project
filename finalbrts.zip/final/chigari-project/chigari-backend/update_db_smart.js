const mysql = require('mysql2/promise');

const update = async () => {
    console.log("Reverting to SMART CORRIDOR Database Structure...");
    const conn = await mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'chigari_app'
    });

    try {
        // 1. Clean existing data
        await conn.query("DELETE FROM bookings");
        await conn.query("DELETE FROM trips");
        await conn.query("DELETE FROM routes");

        console.log("Old data cleared.");

        // 2. Insert Main Corridor Routes ONLY
        // We rely on backend logic to map sub-stops to these main routes
        await conn.query(`
            INSERT INTO routes (id, source, destination, distance_km, estimated_duration) VALUES 
            (1, 'Hubli Railway Station', 'Dharawad New Bustand', 22, '45 mins'),
            (2, 'Dharawad New Bustand', 'Hubli Railway Station', 22, '45 mins')
        `);

        // 3. Insert Frequent Trips (Hubli <-> Dharwad)
        // Every 15 mins
        const trips = [];
        const times = [];
        let h = 6; let m = 0;
        while (h < 22) {
            const timeStr = `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
            times.push(timeStr);
            m += 15;
            if (m >= 60) { m = 0; h++; }
        }

        for (const t of times) {
            // Forward
            trips.push([1, 1, 'Hubli Railway Station', 'Dharawad New Bustand', t, 35.00]);
            // Backward (offset by 30 mins logically but for demo just push same times)
            trips.push([1, 2, 'Dharawad New Bustand', 'Hubli Railway Station', t, 35.00]);

            // Add some Non-AC options randomly
            if (Math.random() > 0.5) {
                trips.push([2, 1, 'Hubli Railway Station', 'Dharawad New Bustand', t, 25.00]);
                trips.push([2, 2, 'Dharawad New Bustand', 'Hubli Railway Station', t, 25.00]);
            }
        }

        for (const t of trips) {
            await conn.query(`
                INSERT INTO trips (bus_id, route_id, source, destination, travel_date, travel_time, price) 
                VALUES (?, ?, ?, ?, CURDATE(), ?, ?)
             `, t);
        }

        console.log(`Inserted ${trips.length} high-frequency corridor trips.`);

    } catch (e) {
        console.error(e);
    } finally {
        conn.end();
    }
};

update();
