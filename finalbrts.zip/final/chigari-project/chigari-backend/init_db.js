const mysql = require('mysql2/promise');

const init = async () => {
  console.log("Initializing Database...");
  // Connect without database selected first
  const conn = await mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: ''
  });

  try {
    await conn.query(`CREATE DATABASE IF NOT EXISTS chigari_app`);
    console.log("Database 'chigari_app' created/verified.");

    await conn.query(`USE chigari_app`);

    // Users
    await conn.query(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        full_name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        phone VARCHAR(15),
        wallet_balance DECIMAL(10,2) DEFAULT 0.00,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    console.log("Table 'users' verified.");

    // Buses
    await conn.query(`
      CREATE TABLE IF NOT EXISTS buses (
        id INT AUTO_INCREMENT PRIMARY KEY,
        bus_number VARCHAR(50) UNIQUE NOT NULL,
        type VARCHAR(50) DEFAULT 'NON-AC',
        total_seats INT DEFAULT 40,
        description VARCHAR(255)
      )
    `);
    console.log("Table 'buses' verified.");

    // Routes
    await conn.query(`
      CREATE TABLE IF NOT EXISTS routes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        source VARCHAR(100) NOT NULL,
        destination VARCHAR(100) NOT NULL,
        distance_km INT,
        estimated_duration VARCHAR(20)
      )
    `);
    console.log("Table 'routes' verified.");

    // Trips
    await conn.query(`
      CREATE TABLE IF NOT EXISTS trips (
        id INT AUTO_INCREMENT PRIMARY KEY,
        bus_id INT,
        route_id INT,
        source VARCHAR(100),
        destination VARCHAR(100),
        travel_date DATE,
        travel_time VARCHAR(20),
        price DECIMAL(10,2) DEFAULT 30.00,
        status ENUM('SCHEDULED', 'COMPLETED', 'CANCELLED') DEFAULT 'SCHEDULED',
        FOREIGN KEY (bus_id) REFERENCES buses(id),
        FOREIGN KEY (route_id) REFERENCES routes(id)
      )
    `);
    console.log("Table 'trips' verified.");

    // Bookings
    await conn.query(`
      CREATE TABLE IF NOT EXISTS bookings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        pnr VARCHAR(20),
        user_id INT,
        trip_id INT,
        seat_number INT,
        passenger_name VARCHAR(100),
        status ENUM('BOOKED', 'CANCELLED') DEFAULT 'BOOKED',
        payment_status VARCHAR(50) DEFAULT 'SUCCESS',
        booked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (trip_id) REFERENCES trips(id)
      )
    `);
    console.log("Table 'bookings' verified.");

    // SEED DATA
    // Insert Buses
    await conn.query(`
      INSERT IGNORE INTO buses (bus_number, type, total_seats, description) VALUES 
      ('KA-25-F-1001', 'AC VOLVO', 45, 'Chigari Smart AC'),
      ('KA-25-F-2050', 'NON-AC', 50, 'Chigari Express'),
      ('KA-63-F-0099', 'ELECTRIC', 40, 'Chigari EV Green'),
      ('KA-22-F-7788', 'SLEEPER', 30, 'Chigari Night Rider')
    `);

    // Insert Routes
    await conn.query(`
      INSERT IGNORE INTO routes (source, destination, distance_km, estimated_duration) VALUES 
      ('Hubballi', 'Dharwad', 22, '45 mins'),
      ('Dharwad', 'Hubballi', 22, '45 mins'),
      ('Hubballi', 'Belgaum', 105, '2.5 hours'),
      ('Belgaum', 'Hubballi', 105, '2.5 hours'),
      ('Hubballi', 'Bangalore', 410, '7 hours')
    `);

    // Insert trips - Need to fetch IDs dynamically to be safe, or just assume IDs if fresh db.
    // We will use nested selects or just hardcoded logic assuming fresh install usually works for these tasks.
    // Using INSERT IGNORE with hardcoded IDs is risky if AI is repeated on existing DB, but acceptable for 'init' script here.

    // We'll clean trips first to avoid duplicates or issues if schema changed
    // await conn.query("DELETE FROM trips"); 

    await conn.query(`
      INSERT IGNORE INTO trips (id, bus_id, route_id, source, destination, travel_date, travel_time, price) VALUES 
      (1, 1, 1, 'Hubballi', 'Dharwad', CURDATE(), '08:00', 45.00),
      (2, 2, 1, 'Hubballi', 'Dharwad', CURDATE(), '08:30', 30.00),
      (3, 3, 1, 'Hubballi', 'Dharwad', CURDATE(), '09:00', 35.00),
      (4, 1, 2, 'Dharwad', 'Hubballi', CURDATE(), '10:00', 45.00),
      (5, 2, 2, 'Dharwad', 'Hubballi', CURDATE(), '10:30', 30.00),
      (6, 4, 3, 'Hubballi', 'Belgaum', CURDATE() + INTERVAL 1 DAY, '22:00', 150.00),
      (7, 1, 5, 'Hubballi', 'Bangalore', CURDATE() + INTERVAL 2 DAY, '21:00', 650.00)
    `);

    console.log("Seed data inserted.");

  } catch (err) {
    console.error("Error during initialization:", err);
  } finally {
    await conn.end();
    console.log("Done.");
  }
};

init();
