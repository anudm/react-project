const pool = require('./db');

const analyze = async () => {
    try {
        const [rows] = await pool.query(`
            SELECT bus_id, route_id, travel_date, travel_time, COUNT(*) as c 
            FROM trips 
            GROUP BY bus_id, route_id, travel_date, travel_time 
            HAVING c > 1
        `);
        console.log("Duplicate Groups Found:", rows.length);
        if (rows.length > 0) {
            console.log("Example duplicate:", rows[0]);
        }
    } catch (e) {
        console.error(e);
    } finally {
        pool.end();
    }
};

analyze();
