-- =============================================
-- UPDATE ROUTES TO REAL BRTS CORRIDOR
-- =============================================

USE chigari_app;

-- 1. Clean existing dummy trips and routes
DELETE FROM bookings; -- Clear dependent bookings first (optional if you want to keep them but IDs might change)
DELETE FROM trips;
DELETE FROM routes;

-- 2. Insert The "Real" Chigari Route (Hubli <-> Dharwad)
INSERT INTO routes (source, destination, distance_km, estimated_duration) VALUES 
('Hubli Railway Station', 'Dharawad New Bustand', 22, '45 mins'),
('Dharawad New Bustand', 'Hubli Railway Station', 22, '45 mins');

-- 3. Insert Frequent Trips for the Corridor
-- We assume bus_id 1 is AC, 2 is Non-AC from previous script. 
-- If buses table was cleared, we need to ensure buses exist. 
-- For safety, we re-insert buses with IGNORE
INSERT IGNORE INTO buses (bus_number, type, total_seats, description) VALUES 
('KA-25-F-1001', 'AC VOLVO', 45, 'Chigari Smart AC'),
('KA-25-F-2050', 'NON-AC', 50, 'Chigari Express'),
('KA-63-F-0099', 'ELECTRIC', 40, 'Chigari EV Green');

-- Insert Trips (Hubli -> Dharwad)
INSERT INTO trips (bus_id, route_id, source, destination, travel_date, travel_time, price) VALUES 
(1, 1, 'Hubli Railway Station', 'Dharawad New Bustand', CURDATE(), '07:00', 35.00),
(2, 1, 'Hubli Railway Station', 'Dharawad New Bustand', CURDATE(), '07:15', 25.00),
(1, 1, 'Hubli Railway Station', 'Dharawad New Bustand', CURDATE(), '07:30', 35.00),
(3, 1, 'Hubli Railway Station', 'Dharawad New Bustand', CURDATE(), '08:00', 30.00),
(1, 1, 'Hubli Railway Station', 'Dharawad New Bustand', CURDATE(), '08:15', 35.00),
(2, 1, 'Hubli Railway Station', 'Dharawad New Bustand', CURDATE(), '08:30', 25.00),
(1, 1, 'Hubli Railway Station', 'Dharawad New Bustand', CURDATE(), '09:00', 35.00),
(3, 1, 'Hubli Railway Station', 'Dharawad New Bustand', CURDATE(), '10:00', 30.00),
(1, 1, 'Hubli Railway Station', 'Dharawad New Bustand', CURDATE(), '17:00', 35.00),
(2, 1, 'Hubli Railway Station', 'Dharawad New Bustand', CURDATE(), '18:00', 25.00);

-- Insert Trips (Dharwad -> Hubli)
INSERT INTO trips (bus_id, route_id, source, destination, travel_date, travel_time, price) VALUES 
(1, 2, 'Dharawad New Bustand', 'Hubli Railway Station', CURDATE(), '07:00', 35.00),
(2, 2, 'Dharawad New Bustand', 'Hubli Railway Station', CURDATE(), '08:00', 25.00),
(3, 2, 'Dharawad New Bustand', 'Hubli Railway Station', CURDATE(), '08:30', 30.00),
(1, 2, 'Dharawad New Bustand', 'Hubli Railway Station', CURDATE(), '09:00', 35.00),
(2, 2, 'Dharawad New Bustand', 'Hubli Railway Station', CURDATE(), '17:30', 25.00),
(1, 2, 'Dharawad New Bustand', 'Hubli Railway Station', CURDATE(), '18:30', 35.00);

SELECT * FROM trips;
