const express = require("express");
const pool = require("../db");
const router = express.Router();

router.get("/trips", async (req, res) => {
  const { source = "", destination = "", date, bus = "" } = req.query;

  // The User's Exact Sequence
  const STOPS = [
    "Hubli Railway Station", "HDMC Hosur", "Hosur Cross", "KIMS",
    "Vidyanagar", "BVB", "Unkal Cross", "Unkal", "Unkal Lake",
    "APMC", "Bairidevarikoppa", "Shantiniketan", "Navanagar",
    "Iskon Temple", "Rayapur", "Sattura", "Toll Naka",
    "Korta Circle", "NTTF", "Jubli Circle", "Dharawad New Bustand"
  ];

  try {
    let q = `
      SELECT t.id AS trip_id, t.source, t.destination, t.travel_date, t.travel_time, t.price, t.status,
             b.bus_number, b.type, b.total_seats, b.description
      FROM trips t
      JOIN buses b ON t.bus_id = b.id
      WHERE 1=1
    `;

    // Check if both source and dest are in our list
    const sIdx = STOPS.findIndex(s => s.toLowerCase() === source.toLowerCase());
    const dIdx = STOPS.findIndex(s => s.toLowerCase() === destination.toLowerCase());

    let isCorridorSearch = (sIdx !== -1 && dIdx !== -1);

    // We only use params array if we use ? placeholders. 
    // Here I construct string for simplicity in complex logic branch, or use params carefully.
    // I will use direct string construction for the corridor fix to avoid index mess

    if (isCorridorSearch) {
      // CORRIDOR LOGIC: 
      let dbSource, dbDest;

      if (sIdx < dIdx) {
        // Going Forward (Hubli -> Dharwad)
        dbSource = 'Hubli Railway Station';
        dbDest = 'Dharawad New Bustand';
      } else {
        // Going Backward (Dharwad -> Hubli)
        dbSource = 'Dharawad New Bustand';
        dbDest = 'Hubli Railway Station';
      }

      // Find trips that match the MAJOR route
      q += ` AND (t.source = '${dbSource}' AND t.destination = '${dbDest}')`;

    } else {
      // Fallback to standard search if user types something random
      if (source) q += ` AND t.source LIKE '%${source}%'`;
      if (destination) q += ` AND t.destination LIKE '%${destination}%'`;
    }

    // Date Logic: If date provided, exact match. 
    // If NO date provided, show ALL trips (history and future).
    // REVERT: Ignoring date filter to match "previous" behavior where all route trips are shown.
    // if (date) {
    //   q += ` AND t.travel_date = '${date}'`;
    // }

    if (bus) q += ` AND b.bus_number = '${bus}'`;

    // ORDER BY Date ASC (so earliest date first), then Time ASC
    q += " ORDER BY t.travel_date ASC, t.travel_time ASC";

    const [rows] = await pool.query(q);

    // MASKING: Show the user's searched stations on the ticket/card
    // even though the backend bus technically runs end-to-end.
    const results = rows.map(r => ({
      ...r,
      source: isCorridorSearch ? source : r.source,
      destination: isCorridorSearch ? destination : r.destination,
    }));

    res.json(results);
  } catch (e) {
    console.error(e);
    res.json({ success: false, message: e.message });
  }
});

module.exports = router;
