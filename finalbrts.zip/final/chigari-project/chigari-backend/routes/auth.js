const express = require("express");
const bcrypt = require("bcryptjs");
const pool = require("../db");
const router = express.Router();

router.post("/register", async (req, res) => {
  const { full_name, email, password } = req.body;

  try {
    const [exist] = await pool.query("SELECT id FROM users WHERE email=?", [email]);
    if (exist.length > 0)
      return res.json({ success: false, message: "Email already exists" });

    const hash = await bcrypt.hash(password, 10);

    await pool.query(
      "INSERT INTO users (full_name, email, password, wallet_balance) VALUES (?,?,?, 500.00)",
      [full_name, email, hash]
    );

    res.json({ success: true });
  } catch (e) {
    console.error(e); // Log error for debugging
    res.json({ success: false, message: e.message }); // Send actual error message
  }
});

router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    const [row] = await pool.query("SELECT * FROM users WHERE email=?", [email]);
    if (row.length === 0) return res.json({ success: false, message: "Invalid login" });

    const user = row[0];
    const match = await bcrypt.compare(password, user.password); // Use 'password' column

    if (!match) return res.json({ success: false, message: "Invalid login" });

    res.json({
      success: true,
      user: {
        id: user.id,
        full_name: user.full_name,
        email: user.email,
        wallet_balance: user.wallet_balance,
        role: user.role,
        phone: user.phone,
        gender: user.gender,
        date_of_birth: user.date_of_birth,
        city: user.city,
        state: user.state,
        created_at: user.created_at
      }
    });
  } catch (e) {
    console.error(e);
    res.json({ success: false, message: "Server error" });
  }
});

module.exports = router;
