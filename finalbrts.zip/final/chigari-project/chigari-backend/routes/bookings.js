const express = require("express");
const pool = require("../db");
const router = express.Router();

router.get("/bookings/:tripId", async (req, res) => {
  const { tripId } = req.params;

  const [rows] = await pool.query(
    "SELECT seat_number FROM bookings WHERE trip_id=? AND payment_status='SUCCESS' AND status='BOOKED'",
    [tripId]
  );

  res.json(rows.map(r => r.seat_number));
});

// Helper to generate PNR
const generatePNR = () => 'PNR' + Math.floor(100000 + Math.random() * 900000);

// Create Booking
router.post("/bookings", async (req, res) => {
  const { user_id, trip_id, passenger_name, seats, source, destination } = req.body;
  const conn = await pool.getConnection();

  try {
    await conn.beginTransaction();

    // Check for existing bookings for the selected seats
    const placeholder = seats.map(() => '?').join(',');
    const [existing] = await conn.query(
      `SELECT seat_number FROM bookings WHERE trip_id = ? AND seat_number IN (${placeholder}) AND status = 'BOOKED'`,
      [trip_id, ...seats]
    );

    if (existing.length > 0) {
      const bookedSeats = existing.map(b => b.seat_number).join(', ');
      await conn.rollback();
      conn.release();
      return res.json({ success: false, message: `Seat(s) ${bookedSeats} are already booked.` });
    }

    const pnr = generatePNR();

    for (let seat of seats) {
      await conn.query(
        "INSERT INTO bookings (pnr, user_id, trip_id, seat_number, passenger_name, payment_status, status, user_source, user_destination) VALUES (?,?,?,?, ?, 'SUCCESS', 'BOOKED', ?, ?)",
        [pnr, user_id, trip_id, seat, passenger_name, source, destination]
      );
    }

    await conn.commit();
    conn.release();
    res.json({ success: true, pnr });
  } catch (e) {
    await conn.rollback();
    console.error("Booking Error:", e);
    conn.release();
    res.json({ success: false, message: "Booking failed: " + e.message });
  }
});

// Cancel Booking
router.put("/bookings/cancel/:id", async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query("UPDATE bookings SET status='CANCELLED' WHERE id=?", [id]);
    res.json({ success: true });
  } catch (e) {
    res.json({ success: false, message: e.message });
  }
});

// PNR Status
router.get("/bookings/pnr/:pnr", async (req, res) => {
  const { pnr } = req.params;
  try {
    const q = `
      SELECT b.id, b.pnr, b.seat_number, b.status, b.passenger_name,
             COALESCE(b.user_source, t.source) as source, 
             COALESCE(b.user_destination, t.destination) as destination,
             t.travel_date, t.travel_time,
             bus.bus_number
      FROM bookings b
      JOIN trips t ON b.trip_id = t.id
      JOIN buses bus ON t.bus_id = bus.id
      WHERE b.pnr = ?
    `;
    const [rows] = await pool.query(q, [pnr]);
    res.json(rows);
  } catch (e) {
    res.json([]);
  }
});

// Get user bookings
router.get("/bookings/user/:userId", async (req, res) => {
  const { userId } = req.params;

  try {
    const q = `
      SELECT b.id, b.pnr, b.seat_number, b.passenger_name, b.status,
             COALESCE(b.user_source, t.source) as source, 
             COALESCE(b.user_destination, t.destination) as destination, 
             t.travel_date, t.travel_time,
             bus.bus_number, bus.type as bus_type
      FROM bookings b
      JOIN trips t ON b.trip_id = t.id
      JOIN buses bus ON t.bus_id = bus.id
      WHERE b.user_id = ?
      ORDER BY b.booked_at DESC
    `;
    const [rows] = await pool.query(q, [userId]);
    res.json({ success: true, bookings: rows });
  } catch (e) {
    console.error(e);
    res.json({ success: false, message: e.message });
  }
});

module.exports = router;
