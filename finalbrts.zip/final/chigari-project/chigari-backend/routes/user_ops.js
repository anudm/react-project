const express = require("express");
const pool = require("../db");
const bcrypt = require("bcryptjs");
const router = express.Router();

// Update Profile
router.put("/user/profile", async (req, res) => {
    const { id, full_name, email, phone, gender, date_of_birth, city, state } = req.body;

    if (!id || !email || !full_name) {
        return res.json({ success: false, message: "Name and Email are required." });
    }

    try {
        // Check if email belongs to another user
        const [exist] = await pool.query("SELECT id FROM users WHERE email=? AND id!=?", [email, id]);
        if (exist.length > 0) {
            return res.json({ success: false, message: "Email already in use by another account." });
        }

        await pool.query(
            `UPDATE users SET full_name=?, email=?, phone=?, gender=?, date_of_birth=?, city=?, state=? WHERE id=?`,
            [full_name, email, phone, gender, date_of_birth, city, state, id]
        );

        // Fetch updated user to return
        const [rows] = await pool.query("SELECT id, full_name, email, phone, gender, date_of_birth, city, state, wallet_balance, role FROM users WHERE id=?", [id]);

        res.json({ success: true, user: rows[0] });
    } catch (e) {
        console.error(e);
        res.json({ success: false, message: e.message });
    }
});

// Change Password
router.put("/user/password", async (req, res) => {
    const { id, currentPassword, newPassword } = req.body;

    try {
        const [rows] = await pool.query("SELECT password FROM users WHERE id=?", [id]);
        if (rows.length === 0) return res.json({ success: false, message: "User not found." });

        const user = rows[0];
        const match = await bcrypt.compare(currentPassword, user.password);

        if (!match) {
            return res.json({ success: false, message: "Incorrect current password." });
        }

        const hash = await bcrypt.hash(newPassword, 10);
        await pool.query("UPDATE users SET password=? WHERE id=?", [hash, id]);

        res.json({ success: true, message: "Password updated successfully." });
    } catch (e) {
        console.error(e);
        res.json({ success: false, message: e.message });
    }
});

// Delete Account
router.delete("/user/:id", async (req, res) => {
    const { id } = req.params;

    try {
        const conn = await pool.getConnection();
        try {
            await conn.beginTransaction();

            // Delete bookings first (or anonymize them if we want to keep stats, but here we just delete)
            await conn.query("DELETE FROM bookings WHERE user_id=?", [id]);

            // Delete user
            await conn.query("DELETE FROM users WHERE id=?", [id]);

            await conn.commit();
            res.json({ success: true });
        } catch (err) {
            await conn.rollback();
            throw err;
        } finally {
            conn.release();
        }
    } catch (e) {
        console.error(e);
        res.json({ success: false, message: "Failed to delete account. " + e.message });
    }
});

module.exports = router;
