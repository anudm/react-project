const express = require("express");
const pool = require("../db");
const router = express.Router();

// =======================
// BUS MANAGEMENT
// =======================

// Get all buses
router.get("/admin/buses", async (req, res) => {
    try {
        const [rows] = await pool.query("SELECT * FROM buses");
        res.json(rows);
    } catch (e) {
        res.status(500).json({ message: e.message });
    }
});

// Add a bus
router.post("/admin/buses", async (req, res) => {
    const { bus_number, type, total_seats, description } = req.body;
    if (!bus_number || !total_seats) return res.status(400).json({ success: false, message: "Bus Number and Seats are required" });

    try {
        // Check duplicate
        const [existing] = await pool.query("SELECT id FROM buses WHERE bus_number=?", [bus_number]);
        if (existing.length > 0) return res.status(400).json({ success: false, message: "Bus Number already exists" });

        await pool.query(
            "INSERT INTO buses (bus_number, type, total_seats, description) VALUES (?, ?, ?, ?)",
            [bus_number, type, total_seats, description]
        );
        res.json({ success: true });
    } catch (e) {
        console.error("Add Bus Error:", e);
        res.status(500).json({ success: false, message: "Database error: " + e.message });
    }
});

// Delete a bus
// Delete a bus
router.delete("/admin/buses/:id", async (req, res) => {
    const { id } = req.params;
    const conn = await pool.getConnection();
    try {
        await conn.beginTransaction();

        // 1. Delete bookings for trips associated with this bus
        // Find trips for this bus
        const [trips] = await conn.query("SELECT id FROM trips WHERE bus_id=?", [id]);
        if (trips.length > 0) {
            const tripIds = trips.map(t => t.id);
            const placeholders = tripIds.map(() => '?').join(',');

            // Delete bookings
            await conn.query(`DELETE FROM bookings WHERE trip_id IN (${placeholders})`, tripIds);

            // Delete trips
            await conn.query("DELETE FROM trips WHERE bus_id=?", [id]);
        }

        // 2. Delete the bus
        await conn.query("DELETE FROM buses WHERE id=?", [id]);

        await conn.commit();
        res.json({ success: true });
    } catch (e) {
        await conn.rollback();
        console.error("Delete Bus Error:", e);
        res.status(500).json({ success: false, message: e.message });
    } finally {
        conn.release();
    }
});

// =======================
// ROUTE MANAGEMENT
// =======================

// Get all routes
router.get("/admin/routes", async (req, res) => {
    try {
        const [rows] = await pool.query("SELECT * FROM routes");
        res.json(rows);
    } catch (e) {
        res.status(500).json({ message: e.message });
    }
});

// Add a route
router.post("/admin/routes", async (req, res) => {
    const { source, destination, distance_km, estimated_duration } = req.body;
    try {
        await pool.query(
            "INSERT INTO routes (source, destination, distance_km, estimated_duration) VALUES (?, ?, ?, ?)",
            [source, destination, distance_km, estimated_duration]
        );
        res.json({ success: true });
    } catch (e) {
        res.status(500).json({ success: false, message: e.message });
    }
});

// Delete a route
router.delete("/admin/routes/:id", async (req, res) => {
    const { id } = req.params;
    try {
        const [trips] = await pool.query("SELECT id FROM trips WHERE route_id=?", [id]);
        if (trips.length > 0) {
            return res.status(400).json({ success: false, message: "Cannot delete route assigned to trips." });
        }
        await pool.query("DELETE FROM routes WHERE id=?", [id]);
        res.json({ success: true });
    } catch (e) {
        res.status(500).json({ success: false, message: e.message });
    }
});


// =======================
// TRIP MANAGEMENT
// =======================

// Get all trips (Admin view - comprehensive)
router.get("/admin/trips", async (req, res) => {
    try {
        const query = `
            SELECT t.id, t.travel_date, t.travel_time, t.price, t.status,
                   b.bus_number, b.type as bus_type,
                   r.source, r.destination, r.estimated_duration
            FROM trips t
            JOIN buses b ON t.bus_id = b.id
            JOIN routes r ON t.route_id = r.id
            ORDER BY t.travel_date DESC, t.travel_time ASC
        `;
        const [rows] = await pool.query(query);
        res.json(rows);
    } catch (e) {
        res.status(500).json({ message: e.message });
    }
});

// Add a trip
router.post("/admin/trips", async (req, res) => {
    const { bus_id, route_id, travel_date, travel_time, price } = req.body;
    try {
        // Fetch route details to populate denormalized source/dest
        const [routeRows] = await pool.query("SELECT source, destination FROM routes WHERE id=?", [route_id]);
        if (routeRows.length === 0) return res.status(400).json({ success: false, message: "Invalid Route ID" });

        const { source, destination } = routeRows[0];

        await pool.query(
            "INSERT INTO trips (bus_id, route_id, source, destination, travel_date, travel_time, price, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'SCHEDULED')",
            [bus_id, route_id, source, destination, travel_date, travel_time, price]
        );
        res.json({ success: true });
    } catch (e) {
        res.status(500).json({ success: false, message: e.message });
    }
});

// Delete a trip (Only if no bookings)
router.delete("/admin/trips/:id", async (req, res) => {
    const { id } = req.params;
    try {
        const [bookings] = await pool.query("SELECT id FROM bookings WHERE trip_id=?", [id]);
        if (bookings.length > 0) {
            return res.status(400).json({ success: false, message: "Cannot delete trip with active bookings." });
        }
        await pool.query("DELETE FROM trips WHERE id=?", [id]);
        res.json({ success: true });
    } catch (e) {
        res.status(500).json({ success: false, message: e.message });
    }
});

module.exports = router;
