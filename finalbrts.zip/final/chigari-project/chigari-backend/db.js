const mysql = require("mysql2/promise");

const pool = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "", // add only if your WAMP has password
  database: "chigari_app"
});

module.exports = pool;
