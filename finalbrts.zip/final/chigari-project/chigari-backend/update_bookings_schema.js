const mysql = require('mysql2/promise');

const update = async () => {
    console.log("Updating Bookings Table to store User Specific Routes...");
    const conn = await mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'chigari_app'
    });

    try {
        // Add columns if they don't exist
        // simple approach: try adding, ignore error if exists
        try {
            await conn.query("ALTER TABLE bookings ADD COLUMN user_source VARCHAR(100) DEFAULT NULL");
            await conn.query("ALTER TABLE bookings ADD COLUMN user_destination VARCHAR(100) DEFAULT NULL");
            console.log("Columns added.");
        } catch (e) {
            console.log("Columns might already exist or error: " + e.message);
        }

    } catch (e) {
        console.error(e);
    } finally {
        conn.end();
    }
};

update();
