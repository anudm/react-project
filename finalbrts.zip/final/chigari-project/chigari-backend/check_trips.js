const pool = require('./db');

const check = async () => {
    try {
        const [rows] = await pool.query("SELECT COUNT(*) as count FROM trips");
        console.log("Total Trips in DB:", rows[0].count);

        const [allTrips] = await pool.query("SELECT id, bus_id, route_id, travel_date, travel_time FROM trips ORDER BY id DESC LIMIT 5");
        console.log("Last 5 trips:", allTrips);

    } catch (e) {
        console.error(e);
    } finally {
        pool.end();
    }
};

check();
