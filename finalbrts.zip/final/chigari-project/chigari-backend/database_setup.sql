CREATE DATABASE IF NOT EXISTS chigari;
USE chigari;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(255),
  email VARCHAR(255) UNIQUE,
  password VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS buses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  bus_number VARCHAR(50),
  total_seats INT DEFAULT 40,
  type VARCHAR(50) DEFAULT 'NON-AC', -- AC, NON-AC, SLEEPER
  description VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS trips (
  id INT AUTO_INCREMENT PRIMARY KEY,
  bus_id INT,
  source VARCHAR(100),
  destination VARCHAR(100),
  travel_date DATE,
  travel_time VARCHAR(20),
  price DECIMAL(10,2) DEFAULT 30.00,
  FOREIGN KEY (bus_id) REFERENCES buses(id)
);

CREATE TABLE IF NOT EXISTS bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  pnr VARCHAR(20) UNIQUE,
  user_id INT,
  trip_id INT,
  seat_number INT,
  passenger_name VARCHAR(100),
  status ENUM('BOOKED', 'CANCELLED') DEFAULT 'BOOKED',
  payment_status VARCHAR(50) DEFAULT 'SUCCESS',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (trip_id) REFERENCES trips(id)
);

-- Insert Dummy Data for Real functionality testing
INSERT IGNORE INTO buses (bus_number, type, description) VALUES 
('KA-25-F-1001', 'AC', 'Chigari AC Volvo'),
('KA-25-F-1002', 'NON-AC', 'Chigari Express'),
('KA-25-F-1003', 'SLEEPER', 'Chigari Night Service');

-- Insert Trips (Ensure dates are relevant or generic)
INSERT IGNORE INTO trips (bus_id, source, destination, travel_date, travel_time, price) VALUES 
(1, 'Hubballi', 'Dharwad', CURDATE(), '08:00', 45.00),
(1, 'Dharwad', 'Hubballi', CURDATE(), '10:00', 45.00),
(2, 'Hubballi', 'Dharwad', CURDATE(), '09:00', 30.00),
(3, 'Hubballi', 'Belgaum', CURDATE() + INTERVAL 1 DAY, '22:00', 150.00);
