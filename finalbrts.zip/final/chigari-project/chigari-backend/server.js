const express = require("express");
const cors = require("cors");

const authRoutes = require("./routes/auth");
const tripsRoutes = require("./routes/trips");
const bookingsRoutes = require("./routes/bookings");
const adminRoutes = require("./routes/admin");
const userOpsRoutes = require("./routes/user_ops");

const app = express();
app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.send("Backend running");
});

app.use("/api", authRoutes);
app.use("/api", tripsRoutes);
app.use("/api", bookingsRoutes);
app.use("/api", adminRoutes);
app.use("/api", userOpsRoutes);

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Backend running on port ${PORT}`);
});
