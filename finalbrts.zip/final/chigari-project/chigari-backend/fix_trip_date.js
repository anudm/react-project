const pool = require('./db');

const fix = async () => {
    console.log("Fixing old trip date for 200A...");
    try {
        // Update trips with year < 2024 to tomorrow
        const [result] = await pool.query("UPDATE trips SET travel_date = CURDATE() + INTERVAL 1 DAY WHERE bus_id = (SELECT id FROM buses WHERE bus_number='200A') AND YEAR(travel_date) < 2024");
        console.log(`Fixed trip date. Affected rows: ${result.affectedRows}`);
    } catch (e) {
        console.error("Error:", e.message);
    } finally {
        pool.end();
    }
};

fix();
